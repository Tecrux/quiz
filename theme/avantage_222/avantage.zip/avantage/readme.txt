== Documentation ==
https://documentation.bold-themes.com/avantage