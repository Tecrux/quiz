<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'desk (CorporateBusiness) ' => $set . '_e900',
	'settings (CorporateBusiness) ' => $set . '_e901',
	'teamwork (CorporateBusiness) ' => $set . '_e902',
	'hierarchical-structure (CorporateBusiness) ' => $set . '_e903',
	'profits (CorporateBusiness) ' => $set . '_e904',
	'lecture (CorporateBusiness) ' => $set . '_e905',
	'job-search (CorporateBusiness) ' => $set . '_e906',
	'list (CorporateBusiness) ' => $set . '_e907',
	'presentation (CorporateBusiness) ' => $set . '_e908',
	'goal (CorporateBusiness) ' => $set . '_e909',
	'laptop (CorporateBusiness) ' => $set . '_e90a',
	'skyscraper (CorporateBusiness) ' => $set . '_e90b',
	'meeting (CorporateBusiness) ' => $set . '_e90c',
	'desk-chair (CorporateBusiness) ' => $set . '_e90d',
	'group (CorporateBusiness) ' => $set . '_e90e',
	'worldwide (CorporateBusiness) ' => $set . '_e90f',
	'curriculum (CorporateBusiness) ' => $set . '_e910',
	'cloud-computing (CorporateBusiness) ' => $set . '_e911',
	'growth (CorporateBusiness) ' => $set . '_e912',
	'thinking (CorporateBusiness) ' => $set . '_e913'
);