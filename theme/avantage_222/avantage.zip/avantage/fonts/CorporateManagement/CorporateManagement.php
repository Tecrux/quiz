<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'brainstorming (CorporateManagement) ' => $set . '_e900',
	'user (CorporateManagement) ' => $set . '_e901',
	'consulting (CorporateManagement) ' => $set . '_e902',
	'care (CorporateManagement) ' => $set . '_e903',
	'deadline (CorporateManagement) ' => $set . '_e904',
	'employee (CorporateManagement) ' => $set . '_e905',
	'employee-1 (CorporateManagement) ' => $set . '_e906',
	'employee-2 (CorporateManagement) ' => $set . '_e907',
	'people (CorporateManagement) ' => $set . '_e908',
	'headhunting (CorporateManagement) ' => $set . '_e909',
	'hierarchy (CorporateManagement) ' => $set . '_e90a',
	'human-resources (CorporateManagement) ' => $set . '_e90b',
	'idea (CorporateManagement) ' => $set . '_e90c',
	'insurance (CorporateManagement) ' => $set . '_e90d',
	'interview (CorporateManagement) ' => $set . '_e90e',
	'success (CorporateManagement) ' => $set . '_e90f',
	'meeting (CorporateManagement) ' => $set . '_e910',
	'consulting-1 (CorporateManagement) ' => $set . '_e911',
	'location-pin (CorporateManagement) ' => $set . '_e912',
	'overtime (CorporateManagement) ' => $set . '_e913',
	'connection (CorporateManagement) ' => $set . '_e914',
	'personal-development (CorporateManagement) ' => $set . '_e915',
	'personal-id (CorporateManagement) ' => $set . '_e916',
	'competence (CorporateManagement) ' => $set . '_e917',
	'manager (CorporateManagement) ' => $set . '_e918',
	'resume (CorporateManagement) ' => $set . '_e919',
	'retirement (CorporateManagement) ' => $set . '_e91a',
	'support (CorporateManagement) ' => $set . '_e91b',
	'seminar (CorporateManagement) ' => $set . '_e91c',
	'workers (CorporateManagement) ' => $set . '_e91d'
);