<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'laptop (SocialMediaAndNetwork) ' => $set . '_e900',
	'network (SocialMediaAndNetwork) ' => $set . '_e901',
	'group (SocialMediaAndNetwork) ' => $set . '_e904',
	'multimedia (SocialMediaAndNetwork) ' => $set . '_e905',
	'man (SocialMediaAndNetwork) ' => $set . '_e906',
	'heart (SocialMediaAndNetwork) ' => $set . '_e907',
	'link (SocialMediaAndNetwork) ' => $set . '_e908',
	'wifi (SocialMediaAndNetwork) ' => $set . '_e909',
	'follow (SocialMediaAndNetwork) ' => $set . '_e90a',
	'browser (SocialMediaAndNetwork) ' => $set . '_e90b',
	'woman (SocialMediaAndNetwork) ' => $set . '_e90c',
	'email (SocialMediaAndNetwork) ' => $set . '_e90d',
	'discussion (SocialMediaAndNetwork) ' => $set . '_e90e',
	'chat-1 (SocialMediaAndNetwork) ' => $set . '_e90f',
	'share (SocialMediaAndNetwork) ' => $set . '_e910',
	'agenda (SocialMediaAndNetwork) ' => $set . '_e911',
	'cloud-computing (SocialMediaAndNetwork) ' => $set . '_e912',
	'chat (SocialMediaAndNetwork) ' => $set . '_e913',
	'blogging (SocialMediaAndNetwork) ' => $set . '_e902',
	'like (SocialMediaAndNetwork) ' => $set . '_e903'
);