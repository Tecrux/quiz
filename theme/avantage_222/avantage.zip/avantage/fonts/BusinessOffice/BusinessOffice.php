<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'teamwork-3 (businessoffice set)' => $set . '_e900',
	'teamwork-2 (businessoffice set)' => $set . '_e901',
	'support (businessoffice set)' => $set . '_e902',
	'management (businessoffice set)' => $set . '_e903',
	'exchange (businessoffice set)' => $set . '_e904',
	'brainstorming (businessoffice set)' => $set . '_e905',
	'gears (businessoffice set)' => $set . '_e906',
	'networking (businessoffice set)' => $set . '_e907',
	'transfer (businessoffice set)' => $set . '_e908',
	'team-3 (businessoffice set)' => $set . '_e909',
	'presentation (businessoffice set)' => $set . '_e90a',
	'strategy (businessoffice set)' => $set . '_e90b',
	'profits (businessoffice set)' => $set . '_e90c',
	'settings (businessoffice set)' => $set . '_e90d',
	'discussion (businessoffice set)' => $set . '_e90e',
	'files (businessoffice set)' => $set . '_e90f',
	'tasks-2 (businessoffice set)' => $set . '_e910',
	'tasks-1 (businessoffice set)' => $set . '_e911',
	'community (businessoffice set)' => $set . '_e912',
	'curriculum (businessoffice set)' => $set . '_e913',
	'puzzle (businessoffice set)' => $set . '_e914',
	'team-2 (businessoffice set)' => $set . '_e915',
	'teamwork-1 (businessoffice set)' => $set . '_e916',
	'communication (businessoffice set)' => $set . '_e917',
	'tasks (businessoffice set)' => $set . '_e918',
	'team-1 (businessoffice set)' => $set . '_e919',
	'man (businessoffice set)' => $set . '_e91a',
	'woman (businessoffice set)' => $set . '_e91b',
	'teamwork (businessoffice set)' => $set . '_e91c',
	'team (businessoffice set)' => $set . '_e91d'
);