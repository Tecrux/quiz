<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'message (CustomerRelationshipManagement) ' => $set . '_e900',
	'guarantee (CustomerRelationshipManagement) ' => $set . '_e901',
	'customer-service (CustomerRelationshipManagement) ' => $set . '_e902',
	'customer-service-1 (CustomerRelationshipManagement) ' => $set . '_e903',
	'survey (CustomerRelationshipManagement) ' => $set . '_e904',
	'hand (CustomerRelationshipManagement) ' => $set . '_e905',
	'dislike (CustomerRelationshipManagement) ' => $set . '_e906',
	'favorite (CustomerRelationshipManagement) ' => $set . '_e907',
	'feedback (CustomerRelationshipManagement) ' => $set . '_e908',
	'info (CustomerRelationshipManagement) ' => $set . '_e909',
	'help (CustomerRelationshipManagement) ' => $set . '_e90a',
	'review (CustomerRelationshipManagement) ' => $set . '_e90b',
	'like (CustomerRelationshipManagement) ' => $set . '_e90c',
	'heart (CustomerRelationshipManagement) ' => $set . '_e90d',
	'loyalty (CustomerRelationshipManagement) ' => $set . '_e90e',
	'smartphone (CustomerRelationshipManagement) ' => $set . '_e90f',
	'feedback-1 (CustomerRelationshipManagement) ' => $set . '_e910',
	'review-1 (CustomerRelationshipManagement) ' => $set . '_e911',
	'phone-call (CustomerRelationshipManagement) ' => $set . '_e912',
	'consulting (CustomerRelationshipManagement) ' => $set . '_e913',
	'conversation (CustomerRelationshipManagement) ' => $set . '_e914',
	'comment (CustomerRelationshipManagement) ' => $set . '_e915',
	'check-mark (CustomerRelationshipManagement) ' => $set . '_e916',
	'smiley (CustomerRelationshipManagement) ' => $set . '_e917',
	'diamond (CustomerRelationshipManagement) ' => $set . '_e918',
	'review-2 (CustomerRelationshipManagement) ' => $set . '_e919',
	'reviews (CustomerRelationshipManagement) ' => $set . '_e91a',
	'24-hours (CustomerRelationshipManagement) ' => $set . '_e91b',
	'support (CustomerRelationshipManagement) ' => $set . '_e91c',
	'bubble-chat (CustomerRelationshipManagement) ' => $set . '_e91d'
);