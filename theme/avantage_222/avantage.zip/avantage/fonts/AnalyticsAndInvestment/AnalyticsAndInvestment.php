<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'analytics (AnalyticsAndInvestment) ' => $set . '_e900',
	'analytics-1 (AnalyticsAndInvestment) ' => $set . '_e901',
	'analytics-2 (AnalyticsAndInvestment) ' => $set . '_e902',
	'balance (AnalyticsAndInvestment) ' => $set . '_e903',
	'brain (AnalyticsAndInvestment) ' => $set . '_e904',
	'briefcase (AnalyticsAndInvestment) ' => $set . '_e905',
	'calculator (AnalyticsAndInvestment) ' => $set . '_e906',
	'coin (AnalyticsAndInvestment) ' => $set . '_e907',
	'contract (AnalyticsAndInvestment) ' => $set . '_e908',
	'flask (AnalyticsAndInvestment) ' => $set . '_e909',
	'hourglass (AnalyticsAndInvestment) ' => $set . '_e90a',
	'investment (AnalyticsAndInvestment) ' => $set . '_e90b',
	'invoice (AnalyticsAndInvestment) ' => $set . '_e90c',
	'light-bulb (AnalyticsAndInvestment) ' => $set . '_e90d',
	'microscope (AnalyticsAndInvestment) ' => $set . '_e90e',
	'money (AnalyticsAndInvestment) ' => $set . '_e90f',
	'money-1 (AnalyticsAndInvestment) ' => $set . '_e910',
	'money-bag (AnalyticsAndInvestment) ' => $set . '_e911',
	'pie-chart (AnalyticsAndInvestment) ' => $set . '_e912',
	'profits (AnalyticsAndInvestment) ' => $set . '_e913',
	'shield (AnalyticsAndInvestment) ' => $set . '_e914',
	'stopwatch (AnalyticsAndInvestment) ' => $set . '_e915',
	'strategy (AnalyticsAndInvestment) ' => $set . '_e916',
	'tablet (AnalyticsAndInvestment) ' => $set . '_e917',
	'visibility (AnalyticsAndInvestment) ' => $set . '_e918'
);