<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'ad (MarketingAndAdvertising) ' => $set . '_e900',
	'thumbs-up (MarketingAndAdvertising) ' => $set . '_e901',
	'banners (MarketingAndAdvertising) ' => $set . '_e902',
	'billboard (MarketingAndAdvertising) ' => $set . '_e903',
	'bookmarks (MarketingAndAdvertising) ' => $set . '_e904',
	'like (MarketingAndAdvertising) ' => $set . '_e905',
	'listening (MarketingAndAdvertising) ' => $set . '_e906',
	'targeting (MarketingAndAdvertising) ' => $set . '_e907',
	'direct (MarketingAndAdvertising) ' => $set . '_e908',
	'ad-1 (MarketingAndAdvertising) ' => $set . '_e909',
	'email (MarketingAndAdvertising) ' => $set . '_e90a',
	'focus (MarketingAndAdvertising) ' => $set . '_e90b',
	'gift (MarketingAndAdvertising) ' => $set . '_e90c',
	'keywords (MarketingAndAdvertising) ' => $set . '_e90d',
	'keywords-1 (MarketingAndAdvertising) ' => $set . '_e90e',
	'leaflet (MarketingAndAdvertising) ' => $set . '_e90f',
	'hands (MarketingAndAdvertising) ' => $set . '_e910',
	'shopping-bag (MarketingAndAdvertising) ' => $set . '_e911',
	'social-media (MarketingAndAdvertising) ' => $set . '_e912',
	'news (MarketingAndAdvertising) ' => $set . '_e913',
	'pay-per-click (MarketingAndAdvertising) ' => $set . '_e914',
	'promotion (MarketingAndAdvertising) ' => $set . '_e915',
	'send (MarketingAndAdvertising) ' => $set . '_e916',
	'shopping-cart (MarketingAndAdvertising) ' => $set . '_e917',
	'statistics (MarketingAndAdvertising) ' => $set . '_e918',
	'target (MarketingAndAdvertising) ' => $set . '_e919',
	'targeting-1 (MarketingAndAdvertising) ' => $set . '_e91a',
	'ad-2 (MarketingAndAdvertising) ' => $set . '_e91b',
	'video-player (MarketingAndAdvertising) ' => $set . '_e91c',
	'viral-marketing (MarketingAndAdvertising) ' => $set . '_e91d'
);