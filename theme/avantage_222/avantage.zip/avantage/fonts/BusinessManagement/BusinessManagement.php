<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'accounting (BusinessManagement) ' => $set . '_e900',
	'agreement (BusinessManagement) ' => $set . '_e901',
	'growth (BusinessManagement) ' => $set . '_e902',
	'idea (BusinessManagement) ' => $set . '_e903',
	'manager (BusinessManagement) ' => $set . '_e904',
	'opportunities (BusinessManagement) ' => $set . '_e905',
	'efficiency (BusinessManagement) ' => $set . '_e906',
	'puzzle (BusinessManagement) ' => $set . '_e907',
	'clothes (BusinessManagement) ' => $set . '_e908',
	'funding (BusinessManagement) ' => $set . '_e909',
	'globe-grid (BusinessManagement) ' => $set . '_e90a',
	'insurance (BusinessManagement) ' => $set . '_e90b',
	'success (BusinessManagement) ' => $set . '_e90c',
	'logical-thinking (BusinessManagement) ' => $set . '_e90d',
	'leadership (BusinessManagement) ' => $set . '_e90e',
	'options (BusinessManagement) ' => $set . '_e90f',
	'manager-1 (BusinessManagement) ' => $set . '_e910',
	'ability (BusinessManagement) ' => $set . '_e911',
	'planning-strategy (BusinessManagement) ' => $set . '_e912',
	'portfolio (BusinessManagement) ' => $set . '_e913',
	'management (BusinessManagement) ' => $set . '_e914',
	'recruitment (BusinessManagement) ' => $set . '_e915',
	'umbrella (BusinessManagement) ' => $set . '_e916',
	'sticky-note (BusinessManagement) ' => $set . '_e917',
	'social-networks (BusinessManagement) ' => $set . '_e918',
	'business-plan (BusinessManagement) ' => $set . '_e919',
	'promotion (BusinessManagement) ' => $set . '_e91a',
	'success-1 (BusinessManagement) ' => $set . '_e91b',
	'time-management (BusinessManagement) ' => $set . '_e91c',
	'vision (BusinessManagement) ' => $set . '_e91d'
);