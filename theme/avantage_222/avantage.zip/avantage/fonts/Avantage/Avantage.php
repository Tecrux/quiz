<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'quote (Avantage) ' => $set . '_e900',
	'quote-stroked (Avantage) ' => $set . '_e901'
);