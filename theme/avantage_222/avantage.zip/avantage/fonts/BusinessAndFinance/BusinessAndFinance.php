<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'balance (BusinessAndFinance) ' => $set . '_e900',
	'briefcase (BusinessAndFinance) ' => $set . '_e901',
	'calculator (BusinessAndFinance) ' => $set . '_e902',
	'coins (BusinessAndFinance) ' => $set . '_e903',
	'compass (BusinessAndFinance) ' => $set . '_e904',
	'contract (BusinessAndFinance) ' => $set . '_e905',
	'diamond (BusinessAndFinance) ' => $set . '_e906',
	'flask (BusinessAndFinance) ' => $set . '_e907',
	'growth (BusinessAndFinance) ' => $set . '_e908',
	'handshake (BusinessAndFinance) ' => $set . '_e909',
	'hourglass (BusinessAndFinance) ' => $set . '_e90a',
	'invoice (BusinessAndFinance) ' => $set . '_e90b',
	'key (BusinessAndFinance) ' => $set . '_e90c',
	'light-bulb (BusinessAndFinance) ' => $set . '_e90d',
	'money (BusinessAndFinance) ' => $set . '_e90e',
	'networking (BusinessAndFinance) ' => $set . '_e90f',
	'networking-1 (BusinessAndFinance) ' => $set . '_e910',
	'notepad (BusinessAndFinance) ' => $set . '_e911',
	'phone-call (BusinessAndFinance) ' => $set . '_e912',
	'pie-chart (BusinessAndFinance) ' => $set . '_e913',
	'presentation (BusinessAndFinance) ' => $set . '_e914',
	'route (BusinessAndFinance) ' => $set . '_e915',
	'speedometer (BusinessAndFinance) ' => $set . '_e916',
	'target (BusinessAndFinance) ' => $set . '_e917',
	'trophy (BusinessAndFinance) ' => $set . '_e918'
);