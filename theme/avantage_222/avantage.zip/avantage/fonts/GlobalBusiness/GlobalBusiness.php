<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'map (GlobalBusiness) ' => $set . '_e900',
	'travel (GlobalBusiness) ' => $set . '_e901',
	'global (GlobalBusiness) ' => $set . '_e902',
	'connection (GlobalBusiness) ' => $set . '_e903',
	'online-banking (GlobalBusiness) ' => $set . '_e904',
	'forum (GlobalBusiness) ' => $set . '_e905',
	'manager (GlobalBusiness) ' => $set . '_e906',
	'global-1 (GlobalBusiness) ' => $set . '_e907',
	'global-network (GlobalBusiness) ' => $set . '_e908',
	'global-2 (GlobalBusiness) ' => $set . '_e909',
	'strategy (GlobalBusiness) ' => $set . '_e90a',
	'vision (GlobalBusiness) ' => $set . '_e90b',
	'globalization (GlobalBusiness) ' => $set . '_e90c',
	'headquarter (GlobalBusiness) ' => $set . '_e90d',
	'agreement (GlobalBusiness) ' => $set . '_e90e',
	'partnership (GlobalBusiness) ' => $set . '_e90f',
	'transaction (GlobalBusiness) ' => $set . '_e910',
	'portfolio (GlobalBusiness) ' => $set . '_e911',
	'money (GlobalBusiness) ' => $set . '_e912',
	'launch (GlobalBusiness) ' => $set . '_e913',
	'location-pin (GlobalBusiness) ' => $set . '_e914',
	'online-banking-1 (GlobalBusiness) ' => $set . '_e915',
	'network (GlobalBusiness) ' => $set . '_e916',
	'online (GlobalBusiness) ' => $set . '_e917',
	'ribbon-cutting (GlobalBusiness) ' => $set . '_e918',
	'agreement-1 (GlobalBusiness) ' => $set . '_e919',
	'configuration (GlobalBusiness) ' => $set . '_e91a',
	'time-zone (GlobalBusiness) ' => $set . '_e91b',
	'transportation (GlobalBusiness) ' => $set . '_e91c',
	'flags (GlobalBusiness) ' => $set . '_e91d'
);