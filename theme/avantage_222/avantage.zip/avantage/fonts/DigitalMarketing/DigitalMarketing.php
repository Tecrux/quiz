<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'announcer (DigitalMarketing) ' => $set . '_e900',
	'billboard (DigitalMarketing) ' => $set . '_e901',
	'browser (DigitalMarketing) ' => $set . '_e902',
	'browser-1 (DigitalMarketing) ' => $set . '_e903',
	'browser-2 (DigitalMarketing) ' => $set . '_e904',
	'cloud-computing (DigitalMarketing) ' => $set . '_e905',
	'comment (DigitalMarketing) ' => $set . '_e906',
	'email (DigitalMarketing) ' => $set . '_e907',
	'funnel (DigitalMarketing) ' => $set . '_e908',
	'idea (DigitalMarketing) ' => $set . '_e909',
	'invoice (DigitalMarketing) ' => $set . '_e90a',
	'laptop (DigitalMarketing) ' => $set . '_e90b',
	'list (DigitalMarketing) ' => $set . '_e90c',
	'loupe (DigitalMarketing) ' => $set . '_e90d',
	'networking (DigitalMarketing) ' => $set . '_e90e',
	'open (DigitalMarketing) ' => $set . '_e90f',
	'pay-per-click (DigitalMarketing) ' => $set . '_e910',
	'placeholder (DigitalMarketing) ' => $set . '_e911',
	'rss (DigitalMarketing) ' => $set . '_e912',
	'smartphone (DigitalMarketing) ' => $set . '_e913',
	'social-network (DigitalMarketing) ' => $set . '_e914',
	'speech-bubble (DigitalMarketing) ' => $set . '_e915',
	'typewriter (DigitalMarketing) ' => $set . '_e916',
	'video-player (DigitalMarketing) ' => $set . '_e917',
	'visibility (DigitalMarketing) ' => $set . '_e918'
);