<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'skills (BusinessPeople) ' => $set . '_e900',
	'achievement (BusinessPeople) ' => $set . '_e901',
	'lightbulb (BusinessPeople) ' => $set . '_e902',
	'people (BusinessPeople) ' => $set . '_e903',
	'opportunities (BusinessPeople) ' => $set . '_e904',
	'customer-service (BusinessPeople) ' => $set . '_e905',
	'people-1 (BusinessPeople) ' => $set . '_e906',
	'headhunting (BusinessPeople) ' => $set . '_e907',
	'idea (BusinessPeople) ' => $set . '_e908',
	'growth (BusinessPeople) ' => $set . '_e909',
	'insurance (BusinessPeople) ' => $set . '_e90a',
	'schedule (BusinessPeople) ' => $set . '_e90b',
	'people-2 (BusinessPeople) ' => $set . '_e90c',
	'leadership (BusinessPeople) ' => $set . '_e90d',
	'meeting (BusinessPeople) ' => $set . '_e90e',
	'motivational-speech (BusinessPeople) ' => $set . '_e90f',
	'online-support (BusinessPeople) ' => $set . '_e910',
	'online (BusinessPeople) ' => $set . '_e911',
	'personal-development (BusinessPeople) ' => $set . '_e912',
	'skills-1 (BusinessPeople) ' => $set . '_e913',
	'choices (BusinessPeople) ' => $set . '_e914',
	'presentation (BusinessPeople) ' => $set . '_e915',
	'report (BusinessPeople) ' => $set . '_e916',
	'deadline (BusinessPeople) ' => $set . '_e917',
	'selection (BusinessPeople) ' => $set . '_e918',
	'conference (BusinessPeople) ' => $set . '_e919',
	'productivity (BusinessPeople) ' => $set . '_e91a',
	'success (BusinessPeople) ' => $set . '_e91b',
	'team (BusinessPeople) ' => $set . '_e91c',
	'time-management (BusinessPeople) ' => $set . '_e91d'
);