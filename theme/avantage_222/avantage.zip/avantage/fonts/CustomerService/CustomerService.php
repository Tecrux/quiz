<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'answer (CustomerService) ' => $set . '_e900',
	'call (CustomerService) ' => $set . '_e901',
	'phone-call (CustomerService) ' => $set . '_e902',
	'conference (CustomerService) ' => $set . '_e903',
	'customer (CustomerService) ' => $set . '_e904',
	'feedback (CustomerService) ' => $set . '_e905',
	'meeting (CustomerService) ' => $set . '_e906',
	'24-hours (CustomerService) ' => $set . '_e907',
	'email (CustomerService) ' => $set . '_e908',
	'fax (CustomerService) ' => $set . '_e909',
	'feedback-1 (CustomerService) ' => $set . '_e90a',
	'forum (CustomerService) ' => $set . '_e90b',
	'help (CustomerService) ' => $set . '_e90c',
	'knowledge (CustomerService) ' => $set . '_e90d',
	'message (CustomerService) ' => $set . '_e90e',
	'smartphone (CustomerService) ' => $set . '_e90f',
	'telephone (CustomerService) ' => $set . '_e910',
	'ui (CustomerService) ' => $set . '_e911',
	'review (CustomerService) ' => $set . '_e912',
	'quality (CustomerService) ' => $set . '_e913',
	'questionary (CustomerService) ' => $set . '_e914',
	'faq (CustomerService) ' => $set . '_e915',
	'question (CustomerService) ' => $set . '_e916',
	'email-1 (CustomerService) ' => $set . '_e917',
	'opinion (CustomerService) ' => $set . '_e918',
	'support (CustomerService) ' => $set . '_e919',
	'checklist (CustomerService) ' => $set . '_e91a',
	'support-1 (CustomerService) ' => $set . '_e91b',
	'manual (CustomerService) ' => $set . '_e91c',
	'manual-1 (CustomerService) ' => $set . '_e91d'
);